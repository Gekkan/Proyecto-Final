USE ProyectoFinal;

INSERT INTO Compras (idCompra, FechaCompra, idCajero, Precio)
VALUES (NEWID(), '08/11/2017', '207b99b5-d4e5-4f80-ac41-1e379661c833', '20'),
(NEWID(), '12/20/2017', 'd01fea8a-007e-4e73-ae23-8d702c4d1fc4', '30'),
(NEWID(), '05/04/2017', '34c58ffc-0176-417c-a8d8-aa1a0e6ff166', '20'),
(NEWID(), '01/02/2018', '643fc6aa-6584-4718-999c-9b5c44ebad7a', '35'),
(NEWID(), '12/24/2017', '42534fec-2bca-4313-9cdb-bace1fb9d529', '50'),
(NEWID(), '06/15/2017', 'cb6257fd-e927-4c18-992c-ad664c1eddbe', '30'),
(NEWID(), '03/29/2018', '57a81516-dcbb-4270-9d3f-c489e4b7e368', '50'),
(NEWID(), '03/18/2018', 'ca950812-e30e-4ab1-ab69-c1ced42ba9db', '40'),
(NEWID(), '10/30/2017', '0dc2e8b0-bd94-4a32-b542-d187bde605b3', '20')
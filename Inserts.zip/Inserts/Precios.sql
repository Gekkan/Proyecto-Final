USE ProyectoFinal;

INSERT INTO Precios (idPrecios, TemporadaAlta, TemporadaBaja, idVentas)
VALUES (NEWID(), '40', '20', '07d47c07-f9f1-4a7f-bef3-0c614de4778a'), (NEWID(), '40', '20', 'f0074f93-9d29-4ec4-98ee-107cc8319f71'),
(NEWID(), '40', '20', '49fffe0d-3dc0-46b0-8441-8451d70bba63'), (NEWID(), '40', '20', '70ce6784-1a93-438c-b712-489db851f205'),
(NEWID(), '40', '20', '82cf0131-b38b-469c-bff0-a7d33e5baf48'), (NEWID(), '40', '20', 'cc669062-ab2a-4ddd-90be-8cdb18a14260'),
(NEWID(), '40', '20', '55b5b1e6-5cb7-4278-9243-d74e439e00b3'), (NEWID(), '40', '20', 'c38d1c9b-2bc3-4d2a-a8f9-b4c757f9f68d'),
(NEWID(), '40', '20', 'd60debfb-8c20-439e-a930-9fc46cbd8a67')
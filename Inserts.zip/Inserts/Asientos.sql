USE ProyectoFinal;

INSERT INTO Asientos (idAsientos, CantidadAsientos, AsientosOcupados, PrecioAsiento)
VALUES (NEWID(), '40', '15', '50'), (NEWID(), '30', '10', '20'), (NEWID(), '40', '0', '80'),
(NEWID(), '40', '05', '60'), (NEWID(), '30', '02', '27'), (NEWID(), '20', '08', '50'),
(NEWID(), '25', '08', '40'), (NEWID(), '40', '0', '30'), (NEWID(), '25', '10', '80'),
(NEWID(), '35', '18', '60'), (NEWID(), '80', '45', '40'), (NEWID(), '30', '29', '60')
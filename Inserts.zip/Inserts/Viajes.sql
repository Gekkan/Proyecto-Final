USE ProyectoFinal;

INSERT INTO Viajes (idViajes, idRutas, idHorarios, idCamion)
VALUES (NEWID(), 'ac0079b8-a631-43a6-b378-12fbbc805618', '31adc0ae-91bb-489a-97f1-2e8decabd087', '2d67225d-6fcf-43e8-aab1-145c1856eee7'), 
(NEWID(), '692b2a53-ac76-4e15-9adf-2b6d9af47f01', '820f4b56-c93d-4d60-8e8e-d3315dec8412', 'b174e5e4-18ff-486a-85c7-1ab79c6248f5'),
(NEWID(), 'c3a0ef6e-62d4-41b9-baff-2bfd1ac78fe2', 'e84e29ce-4417-4983-a4b6-64b4069caecd', '0e508e96-3bc4-42f6-81dc-2ca58f2a1ab9'),
(NEWID(), 'cd74fe49-4aa8-49f7-84b1-38ab5a36708f', '45c837d9-c64b-48c9-ae0d-02000c9ba158', 'cbc51aa1-4514-4c88-95fd-5bf0799ef55c'),
(NEWID(), 'b6ea7d60-2f12-4de0-9abc-573438a133c7', 'a269531f-f2b8-4568-9d18-a47f1008f056', 'edd846a5-c2db-47b3-86e3-96493e2d19da'),
(NEWID(), '6248f1ac-b35a-4f68-a62e-574b6e77dc4a', '0f4ed04d-c441-4274-8ddc-9685194b6804', '6d0bf021-2229-419f-82a5-970812723024'),
(NEWID(), '0423dd83-963d-4dbb-b717-6d1e2d0bd7d3', '3f329092-bd7c-478a-a3a0-81c7604b660f', 'bb06d91c-207b-4bfc-ad99-a5668de856bd'),
(NEWID(), '50432ced-5991-45d9-a038-7a18abd1774a', 'cea46005-c593-4722-8022-ac2eccf20410', 'ba72f1e8-b4a1-4fae-b0c6-a7c2597c97ef'),
(NEWID(), 'ca059efb-6805-4952-9e18-863ca6e2a29a', 'b55eb839-5033-4006-8809-c7acffcefc34', '8ca3b4ed-bb77-46ae-b68e-d823fe1920ad'),
(NEWID(), '81bc8248-8e9c-475e-a125-ea10a9357197', '6d237eb4-6a31-488b-9ef3-94bfd42fd9d1', 'c60ff062-2a21-48b5-8207-f325cd2e041e')
USE ProyectoFinal;

INSERT INTO Empleados (idEmpleados, idPersonas, Puesto, FechaIngreso, idCredencial)
VALUES (NEWID(), '532be955-cdd0-4d24-9e01-9766e463a604', 'Chofer', '10/28/2016', 'c6e08e9b-7a44-44da-9be6-0d766285918a'),
(NEWID(), 'cd845526-dc84-4bee-ad2f-a940e862bebb', 'Chofer', '10/28/2016', '6b39256a-9f38-422e-8c56-0dbfff303c5a'),
(NEWID(), '530614bb-cca3-40f5-a3d5-702ad55467a4', 'Chofer', '10/28/2016', 'b67a7cd8-5b26-40b1-bc24-14a648277c08'),
(NEWID(), '6acc898a-121c-4a3c-8e8f-8cb1ea13dc99', 'Chofer', '10/28/2016', 'ff68c0c6-86d0-477c-a565-28a80c9e817b'),
(NEWID(), '38f87543-9173-4dab-b74a-85ffca777ed2', 'Chofer', '10/28/2016', 'b5e02c61-981b-4328-b2ac-330588be1fc8'),
(NEWID(), '675b03d1-e97c-481d-a243-29baaff9789d', 'Chofer', '10/28/2016', 'c9413497-7dc8-4520-ac85-3868f5dccead'),
(NEWID(), 'a53403b4-9256-49ec-a6ff-1f1728c7ef2f', 'Chofer', '10/28/2016', 'ec9545f7-3ec7-4080-8201-48ab9bfb22b6'),
(NEWID(), 'ec2d6e44-a98b-4167-9426-638d7d2ef64f', 'Chofer', '10/28/2016', '8b9fd65c-0265-48ae-b753-5fd2dda7ba1b'),
(NEWID(), 'ec3fc5e0-63a9-4f1d-804d-bbebaf4719e1', 'Chofer', '10/28/2016', '13e863b3-d8dc-4246-9074-72233b76d63d'),
(NEWID(), 'd8632c64-8c81-4320-85eb-9a217aa44345', 'Chofer', '10/28/2016', '9719e863-a37e-4a3d-8604-864150fdcc5b')

INSERT INTO Empleados (idEmpleados, idPersonas, Puesto, FechaIngreso, idCredencial)
VALUES (NEWID(), 'df9c8533-c21d-4835-8f01-729eead645ca', 'Cajero', '10/28/2016', 'a07509e8-67fc-4e4b-8a68-9545e430d54a'),
(NEWID(), '3bd74fb3-e143-4400-a7f1-29ebb563e687', 'Cajero', '10/28/2016', 'bf4ced52-a476-4e44-b9a0-aade14f963ad'),
(NEWID(), 'd71dfb78-8091-46bf-a0bd-a2481f39b2b0', 'Cajero', '10/28/2016', 'c9eea46d-df89-44fa-b0c1-bb9b45013d71'),
(NEWID(), '40f86606-860e-47d7-abf9-1da491a12111', 'Cajero', '10/28/2016', '0156fc6d-d49d-48aa-ac4e-c7852b410ade'),
(NEWID(), '2d93fb21-0dbc-44a7-9bbd-0832df6d99d0', 'Cajero', '10/28/2016', '7675203e-85e8-41cb-bb79-c7b3bfd99f8d'),
(NEWID(), '01133163-25ef-4458-a23f-a33cc709e95f', 'Cajero', '10/28/2016', 'e06a94f5-1a0d-4221-a1ce-dfc50d585b28'),
(NEWID(), '8a14727d-f3f9-4b25-9f42-246d7d495dd1', 'Cajero', '10/28/2016', '943897f4-c44f-4b10-8268-fadee8e52259'),
(NEWID(), 'e678c08b-1cba-494f-8e6c-9b02718ba8cc', 'Cajero', '10/28/2016', '3e087aff-04a3-495d-9a1a-fc24acc0b000'),
(NEWID(), '7c4c4c9d-bb5d-4052-a384-47710e6d6afb', 'Cajero', '10/28/2016', 'c4aeb505-31df-4a3a-b703-ffdf6e204899')
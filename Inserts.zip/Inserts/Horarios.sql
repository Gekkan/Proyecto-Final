USE ProyectoFinal;

INSERT INTO Horarios (idHorarios, HoraSalida, HoraLlegada, Tiempo)
VALUES (NEWID(), '8:00am', '6:10pm', '10hrs 10min'), (NEWID(), '11:30am', '7:33pm', '8hrs 3min'),
(NEWID(), '9:15am', '10:15am', '25hrs'), (NEWID(), '4:00pm', '6:30am', '14hrs 29min'),
(NEWID(), '2:20pm', '7:40pm', '5hrs 20min'), (NEWID(), '12:00pm', '10:20am', '22hrs 18min'),
(NEWID(), '5:20am', '6:00pm', '12hrs 31min'), (NEWID(), '9:45am', '10:20am', '2hrs 36min'),
(NEWID(), '12:13am', '6:00am', '6hrs 47min'), (NEWID(), '11:20pm', '12:04pm', '13hrs 44min')